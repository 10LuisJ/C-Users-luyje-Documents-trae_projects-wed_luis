Coloca aquí tus archivos:

- Música:
  - Se usa por defecto un archivo local en esta carpeta.
  - Nombres intentados automáticamente (en este orden):
    - lucah-lo-bonita-que-estas.mp3
    - Lucah - Lo Bonita Que Estás (Video Oficial).mp3
    - Lucah - Lo Bonita Que Estas (Video Oficial).mp3
    - Lucah.mp3
    - musica.mp3
  - Si quieres usar otro nombre, pégalo en “Configurar fotos → Enlace de música”
    o cámbialo por uno de los nombres de arriba.

- Fotos:
  - Agrega directamente en esta carpeta:
    - 1.jpg
    - 2.jpg
    - 3.jpg
    - 4.jpg
    - 5.jpg
    - (opcional) 6.jpg

Recomendación:
- Mantén nombres sencillos (1.jpg, 2.jpg, 3.jpg, etc.)
- Formatos soportados: .jpg, .jpeg, .png, .webp
- No necesitas editar el HTML; la página usa assets por defecto
